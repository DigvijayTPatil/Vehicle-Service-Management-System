import React from "react";

export default function Invalid() {
  return (
    <div>
      <h1 className="text-center mt-5">Invalid Page</h1>
    </div>
  );
}
