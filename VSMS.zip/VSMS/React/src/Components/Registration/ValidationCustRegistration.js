import { useEffect, useReducer, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

export default function ValidationCustRegistration() {
  const init = {
    fname: { value: "", error: "", valid: false, touched: false },
    lname: { value: "", error: "", valid: false, touched: false },
    contactno: { value: "", error: "", valid: false, touched: false },
    emailid: { value: "", error: "", valid: false, touched: false },
    cityid: 0,
    areaid: 0,
    questionid: 0,
    roleid: 1,
    answer: { value: "", error: "", valid: false, touched: false },
    lane: { value: "", error: "", valid: false, touched: false },
    pincode: { value: "", error: "", valid: false, touched: false },
    birthdate: { value: "", error: "", valid: false, touched: false },
    userid: { value: "", error: "", valid: false, touched: false },
    password: { value: "", error: "", valid: false, touched: false },
    rpassword: { value: "", error: "", valid: false, touched: false },
  };
  const reducer = (state, action) => {
    switch (action.type) {
      case "update":
        return {
          ...state,
          [action.fld]: {
            ...state[action.fld],
            value: action.value,
            error: action.error,
            valid: action.valid,
            touched: action.touched,
          },
        };
      case "reset":
        return init;
    }
  };
  const [info, dispatch] = useReducer(reducer, init);
  const [allarea, setAllarea] = useState([]);
  const [allcities, setAllcities] = useState([]);
  const [allques, setAllques] = useState([]);
  const navigate = useNavigate();
  const reduxAction = useDispatch();

  const validate = (nm, val) => {
    let error = "";
    let valid = false;
    let touched = true;
    switch (nm) {
      case "emailid":
        const exp1 = /^[a-z0-9]{3,}@[a-z]{3,12}\.[a-z]{2,}$/;

        if (!exp1.test(val)) {
          error = "Invalid Email";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "password":
        const exp2 =
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if (!exp2.test(val)) {
          error =
            "Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "rpassword":
        //const exp11 = password
        console.log(nm + " : " + val);
        if (val !== info.password.value) {
          error = "password is not matching";
          valid = false;
        } else if (val === info.password.value) {
          error = "";
          valid = true;
        }
        break;

      case "fname":
        const exp3 = /^[\w]{3,}$/;
        if (!exp3.test(val)) {
          error = "Atleast 3 Charaters";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "lname":
        const exp4 = /^[\w]{3,}$/;
        if (!exp4.test(val)) {
          error = "Atleast 3 Charaters";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "regno":
        const exp5 = /^[\w]{3,}$/;
        if (!exp5.test(val)) {
          error = "Invalid";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "contactno":
        const exp6 = /^[0-9]{10}$/;
        if (!exp6.test(val)) {
          error = "Invalid Contact Number";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "lane":
        const exp7 = /[\w]{4,}$/;
        if (!exp7.test(val)) {
          error = "Address should be greater than 3 characters";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "answer":
        const exp8 = /[\w]{3,}$/;
        if (!exp8.test(val)) {
          error = "Invalid";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "pincode":
        const exp9 = /^[0-9]{6}$/;
        if (!exp9.test(val)) {
          error = "Invalid Pincode";
        } else {
          error = "";
          valid = true;
        }
        break;

      case "cityid":
        // const exp9 = /^[0-9]{6}$/;
        if (info.val === 0) {
          error = "Please select city";
        } else {
          error = "";
          valid = true;
        }
        break;
    }

    console.log(val + "," + error + "," + valid);
    dispatch({ type: "update", fld: nm, value: val, error, valid, touched });
  };

  const test = (e) => {
    console.log(e.target.value);
  };

  const senddata = (e) => {
    alert("Registration Successfull");
    e.preventDefault();
    const reqOptions = {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(info),
    };
    fetch("http://localhost:8080/registercustomer", reqOptions)
      .then((resp) => resp.json())
      .then((obj) => console.log(JSON.stringify(obj)));
  };

  const getAreas = (id) => {
    fetch("http://localhost:8080/getAreaByCityId?id=" + id)
      .then((resp) => resp.json())
      .then((a) => setAllarea(a));
  };

  useEffect(() => {
    fetch("http://localhost:8080/getCities")
      .then((resp) => resp.json())
      .then((c) => setAllcities(c));

    fetch("http://localhost:8080/getQuestions")
      .then((resp) => resp.json())
      .then((q) => setAllques(q));
  }, []);

  return (
    <div style={{ backgroundColor: "White" }}>
      <div className="container">
        <form>
          <table className="table table-striped">
            <tbody>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="fname">First Name:</label>
                    <input
                      type="text"
                      className="form-control"
                      id="fname"
                      placeholder="Enter fname name"
                      name="fname"
                      value={info.fname.value}
                      onChange={(e) => {
                        validate("fname", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.fname.valid && info.fname.touched
                            ? "block"
                            : "none",
                        color: "red",
                      }}
                    >
                      {info.fname.error}
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="fname">Last Name:</label>
                    <input
                      type="text"
                      className="form-control"
                      id="lname"
                      placeholder="Enter lname name"
                      name="lname"
                      value={info.lname.value}
                      onChange={(e) => {
                        validate("lname", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.lname.valid && info.lname.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.lname.error}
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="fname">Birthdate:</label>
                    <input
                      type="date"
                      className="form-control"
                      id="birthdate"
                      placeholder="Enter fname name"
                      name="birthdate"
                      value={info.birthdate.value}
                      onChange={(e) => {
                        validate("birthdate", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.birthdate.valid && info.birthdate.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.birthdate.error}
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="contactno">Contact Number.:</label>
                    <input
                      type="text"
                      className="form-control"
                      id="contactno"
                      placeholder="Enter  Contact number"
                      name="contactno"
                      value={info.contactno.value}
                      onChange={(e) => {
                        validate("contactno", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.contactno.valid && info.contactno.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.contactno.error}
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="emailid">Email ID:</label>
                    <input
                      type="emailid"
                      className="form-control"
                      id="emailid"
                      placeholder="Enter emailid"
                      name="emailid"
                      value={info.emailid.value}
                      onChange={(e) => {
                        validate("emailid", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.emailid.valid && info.emailid.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.emailid.error}
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="cityid"> Select City</label>
                    <select
                      className="form-group"
                      id="cityid"
                      name="cityid"
                      onChange={(e) => {
                        getAreas(e.target.value);
                        dispatch({
                          type: "update",
                          fld: "cityid",
                          val: e.target.value,
                        });
                      }}
                    >
                      <option>Select One</option>
                      {allcities.map((city) => {
                        return (
                          <option value={city.cityid} key={city.cityid}>
                            {city.cityname}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="areaid"> Select Area</label>
                    <select
                      className="form-group"
                      id="areaid"
                      name="areaid"
                      onChange={(e) => {
                        dispatch({
                          type: "update",
                          fld: "areaid",
                          val: e.target.value,
                        });
                      }}
                    >
                      <option>Select One</option>
                      {allarea.map((area) => {
                        return (
                          <option value={area.areaid} key={area.areaid}>
                            {area.areaname}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="lane"> Address:</label>
                    <input
                      type="text"
                      className="form-control"
                      id="lane"
                      placeholder="Enter Address"
                      name="lane"
                      value={info.lane.value}
                      onChange={(e) => {
                        validate("lane", e.target.value);
                        validate("cityid", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.lane.valid && info.lane.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.lane.error}
                    </div>
                    <div className="form-group">
                      <label htmlFor="pincode"> Pincode :</label>
                      <input
                        type="text"
                        className="form-control"
                        id="pincode"
                        placeholder="Enter Pincode"
                        name="pincode"
                        value={info.pincode.value}
                        onChange={(e) => {
                          validate("pincode", e.target.value);
                        }}
                      />
                      <div
                        id="emailHelp"
                        className="form-text"
                        style={{
                          display:
                            !info.pincode.valid && info.pincode.touched
                              ? "block"
                              : "none",
                        }}
                      >
                        {info.pincode.error}
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="securityid">
                      {" "}
                      Select Security Question
                    </label>
                    <select
                      className="form-group"
                      id="securityid"
                      name="securityid"
                      onChange={(e) => {
                        dispatch({
                          type: "update",
                          fld: "securityid",
                          val: e.target.value,
                        });
                      }}
                    >
                      <option>Select One</option>
                      {allques.map((q) => {
                        return (
                          <option value={q.questionid} key={q.questionid}>
                            {q.questiontext}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="answer"> Answer</label>
                    <input
                      type="text"
                      className="form-control"
                      id="answer"
                      placeholder="Enter Answer"
                      name="answer"
                      value={info.answer.value}
                      onChange={(e) => {
                        validate("answer", e.target.value);
                      }}
                    />
                    <div
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.answer.valid && info.answer.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.answer.error}
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="password">Password:</label>
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      placeholder="Enter password"
                      name="password"
                      value={info.password.value}
                      onChange={(e) => {
                        validate("password", e.target.value);
                      }}
                    />

                    <p
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.password.valid && info.password.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.password.error}
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="form-group">
                    <label htmlFor="rpassword">Re-Enter Password:</label>
                    <input
                      type="password"
                      className="form-control"
                      id="rpassword"
                      placeholder="Re-Enter password"
                      name="rpassword"
                      value={info.rpassword.value}
                      onChange={(e) => {
                        validate("rpassword", e.target.value);
                      }}
                      onBlur={(e) => {
                        validate("rpassword", e.target.value);
                      }}
                    />

                    <p
                      id="emailHelp"
                      className="form-text"
                      style={{
                        display:
                          !info.rpassword.valid && info.rpassword.touched
                            ? "block"
                            : "none",
                      }}
                    >
                      {info.rpassword.error}
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <button
                    type="submit"
                    className="btn btn-primary mb-3"
                    onClick={(e) => {
                      senddata(e);
                    }}
                  >
                    Submit
                  </button>
                </td>
                <td>
                  <button
                    type="reset"
                    className="btn btn-primary mb-3"
                    onClick={() => {
                      dispatch({ type: "reset" });
                    }}
                  >
                    clear
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
  );
}
