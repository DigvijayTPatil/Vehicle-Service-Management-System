export default function TrackProgcees() {
  return (
    <div>
      <div>
        <h3>Service Progress Tracking</h3>
        <hr />
      </div>
    </div>
  );
}
