import { Link, Outlet } from "react-router-dom";
import { NavDropdown } from "react-bootstrap";
import { useSelector } from "react-redux";

export default function AdminHome() {
  const mystate = useSelector((state) => state.logged);
  return (
    <>
      <div>
        <nav
          className="navbar navbar-expand-lg bg-light"
          style={{ boxShadow: "0 10px 10px 0 rgba(0,0,0,.2)" }}
        >
          <div className="container-fluid">
            <a className="navbar-brand" href="/">
              VSMS
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNavDropdown"
              aria-controls="navbarNavDropdown"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNavDropdown">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    aria-current="page"
                    href="/adminhome"
                  >
                    Home
                  </a>
                </li>
                <li>
                  <Link to="view" className="nav-link px-3">
                    View Requests
                  </Link>
                </li>
                <li className="nav-item">
                  <NavDropdown
                    id="nav-dropdown-dark-example"
                    title="Profile"
                    menuVariant="light"
                  >
                    <NavDropdown.Item>
                      <Link to="adminregistration" className="nav-link">
                        Update Profile
                      </Link>
                    </NavDropdown.Item>
                    <NavDropdown.Item>
                      <Link to="adminregistration" className="nav-link">
                        Change Password
                      </Link>
                    </NavDropdown.Item>
                  </NavDropdown>
                </li>

                <li>
                  <Link
                    to="/logout"
                    className="nav-link px-3"
                    //onClick={{ mystate: false }}
                    id="logout"
                  >
                    Logout
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <br />

        <Outlet />
      </div>
    </>
  );
}
