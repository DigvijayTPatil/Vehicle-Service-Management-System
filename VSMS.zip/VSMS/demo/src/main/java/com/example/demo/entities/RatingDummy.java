package com.example.demo.entities;

import java.util.Date;

public class RatingDummy {

	
	int rating,customerid,servicecenterid;
	String comment;
	
	
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public int getServicecenterid() {
		return servicecenterid;
	}
	public void setServicecenterid(int servicecenterid) {
		this.servicecenterid = servicecenterid;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	
}
